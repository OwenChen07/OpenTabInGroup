let previousTab = null;
let backgroundEnabled = true;

function refreshEnabledState() {
  chrome.storage.sync.get({ enabled: true }, (result) => {
    backgroundEnabled = result.enabled !== false;
    if (!backgroundEnabled) {
      previousTab = null;
    }
  });
}

refreshEnabledState();

chrome.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName !== 'sync' || !changes.enabled) {
    return;
  }

  backgroundEnabled = changes.enabled.newValue !== false;
  if (!backgroundEnabled) {
    previousTab = null;
  } else {
    // When re-enabling, cache the currently active tab
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab) {
      previousTab = activeTab;
    }
  }
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  if (!backgroundEnabled) {
    return;
  }

  const tab = await chrome.tabs.get(tabId);
  previousTab = tab;
});

chrome.tabs.onCreated.addListener((newTab) => {
  if (!backgroundEnabled) {
    return;
  }

  if (!previousTab) return;

  const groupId = previousTab.groupId;
  if (groupId === chrome.tabGroups.TAB_GROUP_ID_NONE) return;

  setTimeout(() => {
    chrome.tabs.group({ tabIds: newTab.id, groupId }, () => {
      chrome.tabs.update(newTab.id, { active: true });
    });
  }, 50);
});